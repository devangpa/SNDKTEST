const path = require("path");
const express = require("express");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const cors = require("cors");
let db = require("./Database/dataStruct");

const UserRouter = require("./Routes/userroutes");
const PostRouter = require("./Routes/postroutes");

const app = express();
app.use(cors());
app.options("*", cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());

app.use("/api/v1/user", UserRouter);
app.use("/api/v1/post", PostRouter);

app.all("*", (req, res, next) => {
  res.send("Resourse un Available")
});

const PORT = 3500;

app.listen(PORT, () => {
  console.log(`App Running On Port ${PORT}`);
});
