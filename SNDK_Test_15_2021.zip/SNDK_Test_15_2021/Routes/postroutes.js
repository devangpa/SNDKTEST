const express = require("express");
const router = express.Router();
const PostController = require("./../Controller/Post_Controller");
const AuthMillware = require("./../Controller/AuthMiddleware");

router
  .route("/:id")
  .patch(PostController.UpdatePost)
  .delete(PostController.DeletPost);
router.route("/").post(PostController.createPost).get(PostController.GetMyPost);
module.exports = router;
