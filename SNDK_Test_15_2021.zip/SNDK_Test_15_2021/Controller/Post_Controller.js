const db = require("./../Database/dataStruct");
const config = require("./../config.json");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const url = require("url");
exports.createPost = async (req, res, next) => {
  try {
    let GetToken = req.headers.authorization.split(" ")[1];
    let Authorize = jwt.verify(GetToken, config.secret);
    if (Authorize) {
      console.log(Authorize.id);
      let user_id = Authorize.id;
      let { name, category } = req.body;
      let data = { name, category, user_id };
      const Createpost = new db.Post(data);
      let Post = await Createpost.save();
      res.status(200).json({
        status: "Sucess",
        data: "Created Sucessfully",
      });
    }
  } catch (e) {
    res.status(400).json({
      message: "You Should Login ",
    });
  }
};
exports.UpdatePost = async (req, res, next) => {
  try {
    let GetToken = req.headers.authorization.split(" ")[1];
    let Authorize = jwt.verify(GetToken, config.secret);
    if (Authorize) {
      console.log(Authorize.id);
      let user_id = Authorize.id;


      let Posts = await db.Post.update(req.body, {
        where: { id: req.params.id },
      });
      res.status(200).json({
        status: "Sucess",
        data: "Data Updated SucessFully",
      });
    }
  } catch (e) {
    res.status(400).json({
      message: e.message,
    });
  }
};
exports.GetMyPost = async (req, res, next) => {
  try {
    let GetToken = req.headers.authorization.split(" ")[1];
    let Authorize = jwt.verify(GetToken, config.secret);

    if (Authorize) {
      console.log(Authorize.id);
      let user_id = Authorize.id;
      let UserIDAuthorized = await db.Post.findAll({ where: { user_id: user_id } });

      if (UserIDAuthorized) {
        let queryparams = req.query
        if (!queryparams.name == undefined || !queryparams.category == undefined) {

          queryparams.id = user_id
          Posts = await db.Post.findAll({ where: queryparams })
          res.status(200).json({
            data: Posts,
          });

        } else {

          let Posts = await db.Post.findAll({ attributes: ['category', 'name', 'id'] }, { where: { user_id: user_id } });

          res.status(200).json({
            data: Posts,
          });
        }

      }

      //Search By Field Name

      // Search Of
      // req.query.name
      //   ? (Posts = await db.Post.findAll({ where: { name: name } }))
      //   : (Posts = "No Data");

      //Pagination

      // const page = req.query.page*1||1;
      // const limit = req.query.limit*1||100;

      // const skip = (page-1)*limit;

      // query = query.Skip(skip).limit(limit);

      res.status(200).json({
        data: Posts,
      });
    }
  } catch (e) {
    res.status(400).json({
      message: "Somthing Went wrong",
    });
  }
};

exports.GetAllPost = async (req, res, next) => {
  try {
    let Posts = await db.Post.findAll();
    res.status(200).json({
      status: "Sucess",
      data: Posts,
    });
  } catch (e) {
    res.status(400).json({
      status: "unsucess",
      Message: "There is Not Get Post",
    });
  }
};
exports.DeletPost = async (req, res, next) => {
  try {
    let GetToken = req.headers.authorization.split(" ")[1];
    let Authorize = jwt.verify(GetToken, config.secret);
    if (Authorize) {
      console.log(Authorize.id);
      let user_id = Authorize.id;
      let Posts = await db.Post.destroy({ where: { id: req.params.id } });
      if (data === 0) {
        res.status(200).json({
          status: "Delete Sucessfully",
          data: "NO post To delet",
        });
      } else {

        res.status(200).json({
          status: "Delete Sucessfully",
          data: "Delete SucessFully",
        });
      }

    }
  } catch (e) {
    res.status(400).json({
      message: "Delete Sucessfully",
    });
  }
};
