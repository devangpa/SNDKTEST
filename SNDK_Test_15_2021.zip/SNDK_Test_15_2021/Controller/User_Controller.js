const config = require("./../config.json");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = require("./../Database/dataStruct");

exports.Signup = async (req, res, next) => {
  try {
    let data = await db.User.findOne({ where: { email: req.body.email } });
    if (data) {
      res.status(200).json({
        message: "All Ready Have Registerd Email Id",
      });
    }
    const Usercreate = new db.User(req.body);
    Usercreate.dataValues.passwordHash = await bcrypt.hash(
      req.body.Password,
      8
    );
    await Usercreate.save();
    res.status(200).json({
      status: "success",
      message: "User Signup Sucessfull",
    });
  } catch (e) {
    res.status(400).json({
      status: "Unsucess",
      data: e,
    });
  }
};
exports.Login = async (req, res, next) => {
  try {
    const { email, Password } = req.body;
    if (!email || !Password) {
      res.status(200).json({
        Message: "Please Provice Valid Credential",
      });
    }


    console.log(email)
    let data = await db.User.findOne({ where: { email: email } });
    console.log(data)
    if (data) {

      data = await db.User.findOne({ attributes: ['passwordHash'] }, { where: { email: email } });
      let decrept = await bcrypt.compare(Password, data.passwordHash)
      if (decrept === true) {
        const signToken = (id) => {
          return jwt.sign({ id }, config.secret, {
            expiresIn: "90d",
          });
        };
        let CreateTocken = await signToken(data.id);
        res.status(200).json({
          Tokan: CreateTocken,
        });
      } else {
        res.status(200).json({
          Message: "Wrong Password",
        });
      }

    }

    else {
      res.status(200).json({
        Message: "Need To Signup We Dont Find EmailID",
      });
    }

  } catch (e) {
    res.status(400).json({
      Message: e,
    });
  }
};
