const db = require("./../Database/dataStruct");
exports.AuthMidlaware = async (req, res, next) => {
  try {
    let GetToken = req.headers.authorization.split(" ")[1];
    let Authorize = jwt.verify(GetToken, config.secret);

    if (!Authorize) {
      res.status(400).json({
        message: "Need To Sign In.",
      });
    }
    let user_id = Authorize.id;
    let UserAuthenticated = await db.Post.findAll({
      where: { user_id: user_id },
    });
    if (!UserAuthenticated) {
      res.status(400).json({
        message: "Need To Sign In.",
      });
    }

    next();
  } catch (e) {
    res.status(400).json({
      message: "Need To Sign In.",
    });
  }
};
