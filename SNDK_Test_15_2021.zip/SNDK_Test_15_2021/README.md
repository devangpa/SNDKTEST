
Database Related Instructions

• Create Crud apis for posts (name,category,description,status,user_id)

• Create APIS to user login and registration.

• Each post api should be authenticated by JWT Token

• Create api for post pagination (per page, page_no, search by category, search by name)

• Logged in user can only fetch/modify his/her posts;

• Use any sql database for this.

• Should be done on node js and express.    

• Follow rest api standards

Submit postman collection of all the apis.



Kindlly Consider My Test Submition 

To Start Project 

npm i 
npm start

Please  Mention Your MYSQL Credential 

### Regarding My Suggetion 

-- There is a scope of code optimization in this API  
-- 
-- If Any query Please Feel Free To contact me  : Devang Patel  : 9687065209